import 'package:equatable/equatable.dart';
import '../models/task.dart';

abstract class TasksEvent extends Equatable {
  const TasksEvent();

  @override
  List<Object?> get props => [];
}

class AddTaskEvent extends TasksEvent {
  final Task task;

  const AddTaskEvent(this.task);

  @override
  List<Object?> get props => [task];
}

class ToggleTaskEvent extends TasksEvent {
  final String taskId;

  const ToggleTaskEvent(this.taskId);

  @override
  List<Object?> get props => [taskId];
}

class FilterTasksEvent extends TasksEvent {
  final String filter;

  const FilterTasksEvent(this.filter);

  @override
  List<Object?> get props => [filter];
}
