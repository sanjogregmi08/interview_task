import 'package:equatable/equatable.dart';
import '../models/task.dart';

abstract class TasksState extends Equatable {
  const TasksState();

  @override
  List<Object?> get props => [];
}

class TasksInitialState extends TasksState {}

class TasksLoadedState extends TasksState {
  final List<Task> tasks;
  final String filter;

  const TasksLoadedState(this.tasks, this.filter);

  @override
  List<Object?> get props => [tasks, filter];
}
