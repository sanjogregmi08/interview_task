import 'package:flutter_bloc/flutter_bloc.dart';
import 'tasks_event.dart';
import 'tasks_state.dart';
import '../models/task.dart';

class TasksBloc extends Bloc<TasksEvent, TasksState> {
  List<Task> _tasks = [
    Task(id: '1', title: 'Sample Task 1'),
    Task(id: '2', title: 'Sample Task 2'),
  ];

  TasksBloc() : super(TasksInitialState()) {
    on<AddTaskEvent>((event, emit) {
      _tasks.add(event.task);
      emit(TasksLoadedState(_tasks, 'All'));
    });

    on<ToggleTaskEvent>((event, emit) {
      _tasks = _tasks.map((task) {
        if (task.id == event.taskId) {
          return Task(id: task.id, title: task.title, isCompleted: !task.isCompleted);
        }
        return task;
      }).toList();
      emit(TasksLoadedState(_tasks, 'All'));
    });

    on<FilterTasksEvent>((event, emit) {
      List<Task> filteredTasks;
      if (event.filter == 'Completed') {
        filteredTasks = _tasks.where((task) => task.isCompleted).toList();
      } else if (event.filter == 'Pending') {
        filteredTasks = _tasks.where((task) => !task.isCompleted).toList();
      } else {
        filteredTasks = _tasks;
      }
      emit(TasksLoadedState(filteredTasks, event.filter));
    });
  }
}
